package org.jpedal.gui;

/**
 * provide interface for methods needed for remote printing
 */
public interface UIViewerInt {
	void invokeServerMethod(String s, Object[] objects);
}
