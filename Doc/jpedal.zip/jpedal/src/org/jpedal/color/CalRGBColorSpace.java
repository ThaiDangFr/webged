/*
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* Project Lead:  Mark Stephens (mark@idrsolutions.com)
*
* (C) Copyright 2003, IDRsolutions and Contributors.
*
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* CalRGBColorSpace.java
* ---------------
* (C) Copyright 2003, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*
*
*/
package org.jpedal.color;

import java.awt.Color;
import java.awt.color.ColorSpace;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.Raster;

import org.jpedal.utils.LogWriter;


/**
 * handle CalRGBColorSpace
 */
public class CalRGBColorSpace
	extends  GenericColorSpace{
		
	private int r,g,b;
	
	/**cache for values to stop recalculation*/
	private float lastC=-255,lastI=-255,lastE=-255;	
		
	public CalRGBColorSpace(String whitepoint,String blackpoint,String matrix,String gamma) {
			
		cs = ColorSpace.getInstance(ColorSpace.CS_CIEXYZ);
		
		//setCIEValues(whitepoint,blackpoint,null,matrix,gamma);
		value = ColorSpaces.CalRGB;
		
		/**@todo: 
		 * This currently uses Java's color conversion routines to alter CalRGB to
		 * DeviceRGB. This does not take into account all the settings so does not work :-(
		 * We need to implement the formula instead so we convert the values into DeviceRGB 
		 * values r,g,b and then create a new color with them.
		 * 
		 * This is what we do in Lab colorspaces (obviously formula is different but principle is
		 * the same.
		 * 
		 * The PDF reference contains a detailed write-up of the formulae used (remember the
		 * Spec is normally talking about converting FROM DeviceRGB to CalRGB so we need to think
		 * backwards and reverse some of the formulae
		 * 
		 * I have started to do it by adding the convertToRGB(float C,float I, float E)
		 * method but have not implemented the conversion formulae
		 */
		
	}

	/**
	 * convert to RGB and return as an image
	  */
	final public BufferedImage  dataToRGB(byte[] data,int width,int height) {

		BufferedImage image = null;
		DataBuffer db = new DataBufferByte(data, data.length);
		int size = width * height;

		try {

			for (int i = 0;
				i < size * 3;
				i = i + 3) { //convert all values to rgb

				float cl = db.getElemFloat(i);
				float ca = db.getElemFloat(i + 1);
				float cb = db.getElemFloat(i + 2);

				convertToRGB(cl, ca, cb);

				db.setElem(i, r);
				db.setElem(i + 1, g);
				db.setElem(i + 2, b);

			}

			int[] bands = { 0, 1, 2 };
			image =
				new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Raster raster =
				Raster.createInterleavedRaster(
					db,
					width,
					height,
					width * 3,
					3,
					bands,
					null);
			image.setData(raster);

		} catch (Exception ee) {
			image = null;
			LogWriter.writeLog("Couldn't read JPEG, not even raster: " + ee);
		}

		return image;

	}
	
	/**
	 * set CalRGB color (in terms of rgb)
	 */
	final public void setColor(String[] number_values,int items) {

		//get values (and allow for mapped from separatin where only 1 value
		float[] A = { 1.0f, 1.0f, 1.0f };
		
		//allow for use as alt colorspace which only has one value
		if (items == 3) {
			for (int i = 0; i < items; i++){
				A[i] =Float.parseFloat(number_values[2 - i]);
			//	System.out.println(A[i]);
			}
		}
		
		convertToRGB(A[0],A[1],A[2]);
		
		this.currentColor= new PdfColor(r,g,b);
		}
	
	final private void convertToRGB(float C,float I, float E){
		
			if((lastC==C)&&(lastI==I)&&(lastE==E)){	
				
			}else{
			
			  //calcuate using Tristimulus values
			  r=(int)(C*255);
			  g=(int)(I*255);
			  b =(int)(E*255);
				
			lastC=C;
			lastI=I;
			lastE=E;	
		}
	}

	/**
	 * convert Index to RGB
	  */
	final public byte[] convertIndexToRGB(byte[] index){
		/**
		//array
		int size=index.length;
		byte[] newData=new byte[size];
			
		for(int i=0;i<size-1;i=i+3){
			
			float C=(float)index[i]-128f;
			float I=(float)index[i+1]- 128f;
			float E=(float)index[i+2]-128f;
			
			convertToRGB(C,I,E);
			
			//System.out.println(C+" "+I+" "+E+" = "+r+" "+g+" "+b);

			newData[i]=(byte) r;
			newData[i+1]=(byte) g;
			newData[i+2]=(byte) b;
		  
	  	}
	 	*/
		
		return index;
	}	
}
