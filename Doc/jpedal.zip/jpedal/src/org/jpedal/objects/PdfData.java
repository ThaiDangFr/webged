/*
* ===========================================
* Java Pdf Extraction Decoding Access Library
* ===========================================
*
* Project Info:  http://www.jpedal.org
* Project Lead:  Mark Stephens (mark@idrsolutions.com)
*
* (C) Copyright 2003, IDRsolutions and Contributors.
* 
* 	This file is part of JPedal
*
    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


*
* ---------------
* PdfData.java
* ---------------
* (C) Copyright 2002, by IDRsolutions and Contributors.
*
* Original Author:  Mark Stephens (mark@idrsolutions.com)
* Contributor(s):
*/
package org.jpedal.objects;

import java.util.*;

import org.jpedal.PdfDecoder;
import org.jpedal.grouping.PdfGroupingAlgorithms;
import org.jpedal.color.GenericColorSpace;
import org.jpedal.utils.Fonts;
import org.jpedal.utils.LineBreaker;
import org.jpedal.utils.repositories.Vector_Int;


/**
 * <p>
 * holds text data for extraction & manipulation
 * </p>
 * <p>
 * Pdf routines create 'raw' text data
 * </p>
 * <p>
 * grouping routines will attempt to intelligently stitch together and leave as
 * 'processed data' in this class
 * </p>
 * <p>
 * <b>NOTE ONLY methods (NOT public variables) are part of API </b>
 * </p>
 * We then transfer the data into our generic Storypad object store (which also
 * serves as an examaple of how the data can be used).
 *  
 */
public class PdfData extends StoryData
{

    /**identify type as text*/
    public static final int TEXT = 0;

    /**identify type as image*/
    public static final int IMAGE = 1;

    /**
     * list of elements - each element is a text fragment from the pdf
     */
    private java.util.List  text_objects;
    
    /**holds fields extractred by regexp*/
    Map extractedTextFields=new HashMap(),extractedXMLFields=new HashMap();

    private int pointer=0;

    private StringBuffer markedContent=null;

    private int additionalPageCount=0;

    /**original size*/
    private int originalSize=-1;

    /**holds items we used to create the story*/
    public String[] fragments=new String[max];

    public int[] parent=new int[max];

    /**flag to show x co-ord has been embedded in content*/
    private boolean widthIsEmbedded=false;

    /**test orientation*/
    public static final int HORIZONTAL_LEFT_TO_RIGHT = 0;

    public static final int HORIZONTAL_RIGHT_TO_LEFT = 1;

    public static final int VERTICAL_TOP_TO_BOTTOM = 2;

    public static final int VERTICAL_BOTTOM_TO_TOP = 3;

    /**local store for max and widthheight of page*/
    public float maxY=0,maxX=0;

    public int[] fontSize;

    /**vlaues same for all records in file*/
    private Map globalValues=new HashMap();
    private Map globalSettings=new HashMap();

    /**flagged if marked content read*/
	private boolean isMarked=false;


	/** create empty object to hold content*/
	public PdfData()
	{
		text_objects = new Vector();

		//set all parent values
		for(int i=0;i<max;i++)
			parent[i]=-1;
	}

    /**
     * get data as a Map
     */
    final public Map getTextElementAt( int i )
    {
        return (Map)text_objects.get( i );
    }


    /**
     * get number of raw objects on page
     */
    final public int getRawTextElementCount()
    {

        return pointer;
    }

    /**
     * reset values
     */
    final public void resetTextList( java.util.List new_text_objects )
    {
        text_objects = new_text_objects;


    }

    //////////////////////////////////////////////////////////////////
    /**
     * clear store of objects once written out
     * to reclaim memory. If flag set, sets data to
     * state after page decoded before grouping for reparse
     */
    final public void flushTextList( boolean reinit )
    {
        text_objects=new Vector();

        if( reinit == false ){

            pointer=0;

            contents=new String[max];
            f_writingMode=new int[max];
            f_font_used=new String[max];
            font_data=new String[max];
            text_length=new int[max];
            lineCount=new int[max];
            move_command=new int[max];
            f_character_spacing=new float[max];
            token_counter=new int[max];
            f_end_font_size=new int[max];
            space_width=new float[max];
            f_x1=new float[max];
            colorTag=new String[max];
            f_x2=new float[max];
            f_y1=new float[max];
            f_y2=new float[max];

        }
    }

    /////////////////////////////////////////////////////////////////
    /**
     * get number of objects at end
     */
    final public int getTextElementCount()
    {
        return text_objects.size();
    }

    /**
     * store line of raw text for later processing
     */
    final public void addImageElement( float x1, float y1, float width, float height,
                                       String imageName){

        f_x1[pointer]=x1;
        objectType[pointer]=IMAGE;
        f_x2[pointer]=x1+width;
        f_y1[pointer]=y1+height;
        f_y2[pointer]=y1;
        fragments[pointer]=""+pointer;
        contents[pointer]=imageName;
        unformattedContent[pointer]=imageName;

        pointer++;

        //resize pointers
        if(pointer==max){
            resizeArrays(0);
        }
        
    }

	/**
	 * break line in half
	 */
	final public void breakLineInHalf(int original, float x1, float y1, float x2, float y2,boolean debugFlag){

		if(debugFlag)
			System.out.println("id="+original+" x1,y1="+x1+" "+y1+" x2,y2="+x2+" "+y2+"\n"+contents[original]);
		
		/**clone values*/
		f_writingMode[pointer]=f_writingMode[original];
		font_data[pointer]=font_data[original];
		move_command[pointer]=move_command[original];
		f_character_spacing[pointer]=f_character_spacing[original];
		colorTag[pointer]=colorTag[original];

		objectType[pointer]=TEXT;

		token_counter[pointer]=token_counter[original];

		f_end_font_size[pointer]=f_end_font_size[original];

		f_font_used[pointer]=f_font_used[original];

		space_width[pointer]=space_width[original];


        LineBreaker breaker=new LineBreaker();

        breaker.breakLine(contents[original], x1, y1, x2, y2, debugFlag);

        //reset co-ordinates

		f_x1[pointer]=breaker.endX;
		f_x2[pointer]=f_x2[original]; //DO THIS BEFORE WE RESET BELOW!

		f_x1[original]=f_x1[original];
		f_x2[original]=breaker.startX;


		f_y1[pointer]=f_y1[original];
		f_y2[pointer]=f_y2[original];

		//alter text  (adding XML tags)
		text_length[pointer]=breaker.charsCounted;
		text_length[original]=text_length[original]-breaker.charsCounted;

		StringBuffer truncated=new StringBuffer();
		truncated.append(contents[original].substring(0,breaker.brk).trim());

		StringBuffer removedString=new StringBuffer();
		removedString.append(contents[original].substring(breaker.brk,contents[original].length()).trim());

		//add tokens
		if(PdfDecoder.isXMLExtraction()){
			removedString.insert( 0, font_data[pointer] );
			truncated.append( Fonts.fe );
		}

		//add color token
		if(isColorExtracted()){
			removedString.insert( 0, colorTag[pointer] );
			truncated.append( GenericColorSpace.ce );
		}


		contents[original]=truncated.toString();
		contents[pointer]=removedString.toString();
		
		lineCount[pointer]=lineCount[original];

		 /**/
		//System.out.println("start,end="+startX+" "+endX);
		//System.out.println("P="+p+" "+contents[original].length()+" j="+original);
		if(debugFlag){
			System.out.println("orig="+org.jpedal.grouping.PdfGroupingAlgorithms.removeHiddenMarkers(truncated.toString())+"<");
			System.out.println("original at "+f_x1[original]+" "+f_y1[original]+" "+f_x2[original]+" "+f_y2[original]);

			System.out.println("removed="+org.jpedal.grouping.PdfGroupingAlgorithms.removeHiddenMarkers(removedString.toString())+"<");
			System.out.println("removed at "+f_x1[pointer]+" "+f_y1[pointer]+" "+f_x2[pointer]+" "+f_y2[pointer]);

			//if(org.jpedal.grouping.PdfGroupingAlgorithms.removeHiddenMarkers(truncated.toString()).length()==7){
			//	System.out.println("exting");
			//System.exit(1);
			//}
		}


		//
		//System.out.println("second at "+f_x1[pointer]+" "+f_y1[pointer]+" "+f_x2[pointer]+" "+f_y2[pointer]);

		pointer++;

		//resize pointers
		if(pointer==max)
			resizeArrays(0);

	}


	/**
	 * store line of raw text for later processing
	 */
	final public void insertItem(int original,int itemToMerge, float x1, float y1, float x2, float y2,boolean debugFlag){


		// debugFlag=true;

		if(debugFlag)
			System.out.println("id="+original+" x1,y1="+x1+" "+y1+" x2,y2="+x2+" "+y2+"\n"+contents[original]);

		/**
		 * work through text, to find insertion point
		 */
		int p=0,end=contents[original].length();
		char[] line=contents[original].toCharArray();
		String raw=contents[original];
		String value="",pt_reached = "", char_width = "";
		int charsCounted=0;
		float endX=0,startX=0;
		int brk=0;
		float ptReached=0,lastPt=0;

		//System.out.println(contents[original]);

		while(p<end){

			//only data between min and y locations
			while (true) {

				/**
				 * read value
				 */

				if(line[p]!= PdfGroupingAlgorithms.MARKER2){
					//find second marker and get width
					int startPointer=p;
					while((p<end)&&(line[p]!=PdfGroupingAlgorithms.MARKER2))
						p++;
					value = raw.substring(startPointer,p);

				}else{// read the next token and its location and width

					//find first marker
					while((p<end)&&(line[p]!=PdfGroupingAlgorithms.MARKER2))
						p++;

					p++;

					//find second marker and get width
					int startPointer=p;
					while((p<end)&&(line[p]!=PdfGroupingAlgorithms.MARKER2))
						p++;
					pt_reached = raw.substring(startPointer,p);
					p++;

					//find third marker
					startPointer=p;
					while((p<end)&&(line[p]!=PdfGroupingAlgorithms.MARKER2))
						p++;

					char_width=raw.substring(startPointer,p);
					p++;

					//find next marker and number of chars
					startPointer=p;
					while((p<end)&&(line[p]!=PdfGroupingAlgorithms.MARKER2)){
						charsCounted++;
						p++;
					}

					value = raw.substring(startPointer,p);

					ptReached=Float.parseFloat(pt_reached);

					lastPt=ptReached+Float.parseFloat(char_width);

					//update pointers
					if(lastPt  < x1){
						brk=p;
					}

					//if(debugFlag)
					//	System.out.println(value+" "+ptReached+" "+char_width+" startX="+startX+" endX="+endX);

					if (ptReached  > x2)
						break;

					value = "";

				}

				if(p>=end)
					break;
			}
		}

		StringBuffer truncated=new StringBuffer(contents[original]);
		truncated.insert(brk,contents[original]);
		 /**
		//add tokens
		if(PdfDecoder.isXMLExtraction()){
			removedString.insert( 0, font_data[pointer] );
			truncated.append( Fonts.fe );
		}

		//add color token
		if(isColorExtracted()){
			removedString.insert( 0, colorTag[pointer] );
			truncated.append( GenericColorSpace.ce );
		}   */

		//adjust arrays
		pointer--;

		contents[original]=truncated.toString();
		contents[itemToMerge]=null;

	}


	/**
     * store line of raw text for later processing
     */
    final public void addRawTextElement( float character_spacing,int writingMode,
                                         String font_as_string,  float current_space, TextState current_text_state,
                                         float x1, float y1, float x2, float y2, int move_type,
                                         StringBuffer processed_line, int token_number, int current_text_length, String currentColorTag )
    {

        //if( ( x1 >= 0 ) && ( y1 >= 0 ) && ( x2 > 0 ) && ( y2 > 0 ) && (processed_line.length()>0)  )
        if(processed_line.length()>0){

            //add fonts to processed data - duplicates stripped out at end
            //if(PdfDecoder.isXMLExtraction())
            //processed_line = translateCharacters( processed_line );

            //add tokens
            if(PdfDecoder.isXMLExtraction()){
                processed_line.insert( 0, font_as_string );
                processed_line.append( Fonts.fe );
            }

            //add color token
            if(isColorExtracted()){
                processed_line.insert( 0, currentColorTag );
                processed_line.append( GenericColorSpace.ce );
            }

            f_writingMode[pointer]=writingMode;
            font_data[pointer]=font_as_string;
            text_length[pointer]=current_text_length;
            move_command[pointer]=move_type;
            f_character_spacing[pointer]=character_spacing;
            f_x1[pointer]=x1;
            colorTag[pointer]=currentColorTag;
            f_x2[pointer]=x2;
            f_y1[pointer]=y1;
            f_y2[pointer]=y2;
            objectType[pointer]=TEXT;
            lineCount[pointer]=1;
            //raw_data[pointer]=commands_processed.toString();
            contents[pointer]=processed_line.toString();
            token_counter[pointer]=token_number;

            int font_size = current_text_state.getCurrentFontSize();
            f_end_font_size[pointer]=font_size;

            f_font_used[pointer]=current_text_state.getFontName();

            space_width[pointer]=current_space*1000;

            pointer++;

            //resize pointers
            if(pointer==max)
                resizeArrays(0);
        }
    }

    /**
     * store line of raw text for later processing
     */
    final public void addRawBrokenFragment(int j, StringBuffer text, float x1,float x2,
                                           float y1,float y2,String plotString ,String currentColorTag){

        //make sure valid positive co-ords
        if( ( x1 > 0 ) & ( y1 > 0 ) & ( x2 > 0 ) & ( y2 > 0 ) )
        {

            //add fonts to processed data - duplicates stripped out at end
            //processed_line = translateCharacters( processed_line );

            //add token to close
            if(PdfDecoder.isXMLExtraction()){
                if((!text.toString().endsWith(Fonts.fe))&&
                        (!text.toString().endsWith(GenericColorSpace.ce)))
                    text.append(Fonts.fe );
            }

            f_writingMode[pointer]=f_writingMode[j];
            font_data[pointer]=font_data[j];
            text_length[pointer]=text_length[j];
            lineCount[pointer]=lineCount[j];
            move_command[pointer]=move_command[j];
            f_character_spacing[pointer]=f_character_spacing[j];
            f_x1[pointer]=x1;
            f_x2[pointer]=x2;
            f_y1[pointer]=y1;
            f_y2[pointer]=y2;
            colorTag[pointer]=currentColorTag;

            //System.out.println("broken before="+contents[pointer]);
            contents[pointer]=text.toString();
            token_counter[pointer]=token_counter[j];

            f_end_font_size[pointer]=f_end_font_size[j];
            f_font_used[pointer]=f_font_used[j];
            space_width[pointer]=space_width[j];

            pointer++;

            //resize pointers
            if(pointer==max)
                resizeArrays(0);
        }
    }

    /**
     * used by Storypad
     */
    public void restoreToOriginal(){

        additionalPageCount=0;

        if(originalSize!=-1){
            resizeArrays(-originalSize);
            originalSize=-1;
        }
    }

    /**
    * used by Storypad
    */
    public PdfData restorePageContent(int pageNumber,int start,int length) {

        //object to extract data into
        PdfData newData=new PdfData();

        newData.resizeArrays(-length);

        int max=length;

        this.pointer=length;

        System.arraycopy( contents, start, newData.contents, 0, length );

        System.arraycopy( rawData, start, newData.rawData, 0, length );

        System.arraycopy( unformattedContent, start, newData.unformattedContent, 0, length );

        System.arraycopy( f_writingMode, start, newData.f_writingMode, 0, length );

        System.arraycopy( f_font_used, start, newData.f_font_used, 0, length );

        System.arraycopy( colorTag, start, newData.colorTag, 0, length );

        System.arraycopy( font_data, start, newData.font_data, 0, length );

        System.arraycopy( fragments, start, newData.fragments, 0, length );

        for(int jj=length;jj<max;jj++){
            if(fragments[jj]!=null){
                StringTokenizer tokens=new StringTokenizer(newData.fragments[jj]);

                StringBuffer newValue=new StringBuffer();
                int count=tokens.countTokens();
                for(int ii=0;ii<count;ii++){
                    int id=Integer.parseInt(tokens.nextToken())-start;
                    newValue.append(id);
                    newValue.append(' ');
                }

                newData.fragments[jj]=newValue.toString();
            }
        }

        System.arraycopy( text_length, start, newData.text_length, 0, length );

        System.arraycopy( lineCount, start, newData.lineCount, 0, length );

        System.arraycopy( move_command, start, newData.move_command, 0, length );

        System.arraycopy( f_character_spacing, start, newData.f_character_spacing, 0, length );

        System.arraycopy( parent, start, newData.parent, 0, length );

        for(int jj=length;jj<max;jj++){
            if(newData.parent[jj]!=-1)
                newData.parent[jj]=newData.parent[jj]-start;
        }

        System.arraycopy( prefix, start, newData.prefix, 0, length );

        System.arraycopy( token_counter, start, newData.token_counter, 0, length );

        System.arraycopy( links, start, newData.links, 0, length );

        for(int jj=length;jj<max;jj++){

            if(newData.links[jj]!=null){
                int[] current=(int[])newData.links[jj];
                int count=current.length;

                for(int jj2=0;jj2<count;jj2++){

                    if(current[jj2]!=-1)
                        current[jj2]=current[jj2]-start;
                }

                newData.links[jj]=current;

            }
        }

        System.arraycopy( category, start, newData.category, 0, length );

        System.arraycopy( objectType, start, newData.objectType, 0, length );

        System.arraycopy( f_end_font_size, start, newData.f_end_font_size, 0, length );

        System.arraycopy( space_width, start, newData.space_width, 0, length );

        System.arraycopy( f_x1, start, newData.f_x1, 0, length );

        System.arraycopy( f_x2, start, newData.f_x2, 0, length );

        System.arraycopy( f_y1, start, newData.f_y1, 0, length );

        System.arraycopy( f_y2, start, newData.f_y2, 0, length );

        return newData;
    }


    /**
     * used by Storypad
     */
    public void merge(PdfData pdf_data, int xDisplacement,int rawCount) {

        additionalPageCount++;

        if(originalSize==-1)
            originalSize=f_x1.length;


        int existItems=this.getRawTextElementCount();

        if(existItems>f_x1.length)
            existItems=f_x1.length;
        int newItems=pdf_data.getRawTextElementCount();
        if(newItems>pdf_data.f_x1.length)
            newItems=pdf_data.f_x1.length;

        int max=existItems+newItems;

        this.pointer=max;

        //first add xDisplacement onto X2
        for(int i=0;i<newItems;i++){
            pdf_data.f_x1[i]=xDisplacement+pdf_data.f_x1[i];
            pdf_data.f_x2[i]=xDisplacement+pdf_data.f_x2[i];
        }

        float[] temp_f;
        int[] temp_i;
        boolean[] temp_b;
        String[] temp_s;


        temp_s=contents;
        contents = new String[max];
        System.arraycopy( temp_s, 0, contents, 0, existItems );
        System.arraycopy( pdf_data.contents, 0, contents, existItems, newItems);

        temp_s=rawData;
        rawData = new String[max];
        System.arraycopy( temp_s, 0, rawData, 0, existItems );
        System.arraycopy( pdf_data.rawData, 0, rawData, existItems, newItems );

        temp_s=unformattedContent;
        unformattedContent = new String[max];
        System.arraycopy( temp_s, 0, unformattedContent, 0, existItems );
        System.arraycopy( pdf_data.unformattedContent, 0, unformattedContent, existItems, newItems );

        temp_i=f_writingMode;
        f_writingMode=new int[max];
        f_writingMode = new int[max];
        System.arraycopy( temp_i, 0, f_writingMode, 0, existItems );
        System.arraycopy( pdf_data.f_writingMode, 0, f_writingMode, existItems, newItems );

        temp_s=f_font_used;
        f_font_used = new String[max];
        System.arraycopy( temp_s, 0, f_font_used, 0, existItems );
        System.arraycopy( pdf_data.f_font_used, 0, f_font_used, existItems, newItems);

        temp_s=colorTag;
        colorTag = new String[max];
        System.arraycopy( temp_s, 0, colorTag, 0, existItems );
        System.arraycopy( pdf_data.colorTag, 0, colorTag, existItems, newItems );

        temp_s=font_data;
        font_data = new String[max];
        System.arraycopy( temp_s, 0, font_data, 0, existItems );
        System.arraycopy( pdf_data.font_data, 0, font_data, existItems, newItems );

        temp_s=fragments;
        fragments = new String[max];
        System.arraycopy( temp_s, 0, fragments, 0, existItems );
        System.arraycopy( pdf_data.fragments, 0, fragments, existItems, newItems );

        for(int jj=existItems;jj<max;jj++){
            if(fragments[jj]!=null){
                StringTokenizer tokens=new StringTokenizer(fragments[jj]);

                StringBuffer newValue=new StringBuffer();
                int count=tokens.countTokens();
                for(int ii=0;ii<count;ii++){
                    int id=Integer.parseInt(tokens.nextToken())+rawCount;
                    newValue.append(id);
                    newValue.append(' ');
                }

                fragments[jj]=newValue.toString();
            }
        }

        temp_i=text_length;
        text_length = new int[max];
        System.arraycopy( temp_i, 0, text_length, 0, existItems );
        System.arraycopy( pdf_data.text_length, 0, text_length, existItems, newItems);

        temp_i=lineCount;
        lineCount = new int[max];
        System.arraycopy( temp_i, 0, lineCount, 0, existItems );
        System.arraycopy( pdf_data.lineCount, 0, lineCount, existItems, newItems);

        temp_i=move_command;
        move_command = new int[max];
        System.arraycopy( temp_i, 0, move_command, 0, existItems );
        System.arraycopy( pdf_data.move_command, 0, move_command, existItems, newItems);

        temp_f=f_character_spacing;
        f_character_spacing = new float[max];
        System.arraycopy( temp_f, 0, f_character_spacing, 0, existItems );
        System.arraycopy( pdf_data.f_character_spacing, 0, f_character_spacing, existItems, newItems);

        temp_i=parent;
        parent = new int[max];
        //set to default -1
        for(int ii=existItems;ii<max;ii++)
            parent[ii]=-1;
        System.arraycopy( temp_i, 0, parent, 0, existItems );
        System.arraycopy( pdf_data.parent, 0, parent, existItems, newItems);

        for(int jj=existItems;jj<max;jj++){

            if(parent[jj]!=-1)
            parent[jj]=parent[jj]+existItems;
        }

        temp_s=prefix;
        prefix = new String[max];
        //set to default -1
        for(int ii=existItems;ii<max;ii++)
            prefix[ii]=null;
        System.arraycopy( temp_s, 0, prefix, 0, existItems );
        System.arraycopy( pdf_data.prefix, 0, prefix, existItems, newItems);

        temp_i=token_counter;
        token_counter = new int[max];
        System.arraycopy( temp_i, 0, token_counter, 0, existItems );
        System.arraycopy( pdf_data.token_counter, 0, token_counter, existItems, newItems);

        Object[] temp_o=links;
        links = new Object[max];
        System.arraycopy( temp_o, 0, links, 0, existItems );
        System.arraycopy( pdf_data.links, 0, links, existItems, newItems);

        for(int jj=existItems;jj<max;jj++){

            if(links[jj]!=null){
                int[] current=(int[])links[jj];
                int count=current.length;

                for(int jj2=0;jj2<count;jj2++){

                    if(current[jj2]!=-1)
                    current[jj2]=current[jj2]+existItems;
                }

                links[jj]=current;

            }
        }

        temp_s=category;
        category = new String[max];
        System.arraycopy( temp_s, 0, category, 0, existItems );
        System.arraycopy( pdf_data.category, 0, category, existItems, newItems);

        temp_i=objectType;
        objectType = new int[max];
        System.arraycopy( temp_i, 0, objectType, 0, existItems );
        System.arraycopy( pdf_data.objectType, 0, objectType, existItems, newItems);


        temp_i=f_end_font_size;
        f_end_font_size = new int[max];
        System.arraycopy( temp_i, 0, f_end_font_size, 0, existItems );
        System.arraycopy( pdf_data.f_end_font_size, 0, f_end_font_size, existItems, newItems);


        temp_f=space_width;
        space_width = new float[max];
        System.arraycopy( temp_f, 0, space_width, 0, existItems );
        System.arraycopy( pdf_data.space_width, 0, space_width, existItems, newItems);

        temp_f=f_x1;
        f_x1 = new float[max];
        System.arraycopy( temp_f, 0, f_x1, 0, existItems );
        System.arraycopy( pdf_data.f_x1, 0, f_x1, existItems, newItems);

        temp_f=f_x2;
        f_x2 = new float[max];
        System.arraycopy( temp_f, 0, f_x2, 0, existItems );
        System.arraycopy( pdf_data.f_x2, 0, f_x2, existItems, newItems);

        temp_f=f_y1;
        f_y1 = new float[max];
        System.arraycopy( temp_f, 0, f_y1, 0, existItems );
        System.arraycopy( pdf_data.f_y1, 0, f_y1, existItems, newItems);


        temp_f=f_y2;
        f_y2 = new float[max];
        System.arraycopy( temp_f, 0, f_y2, 0, existItems );
        System.arraycopy( pdf_data.f_y2, 0, f_y2, existItems, newItems);

        System.out.println("Merge done");
    }


    /**
     * resize arrays to add newItems to end (-1 makes it grow)
     */
    public void resizeArrays(int newItems) {

        float[] temp_f;
        int[] temp_i;
        boolean[] temp_b;
        String[] temp_s;

        if(newItems<0){
            max=-newItems;
			pointer=max;
        }else if(newItems==0){
			if(max<5000)
				max=max*5;
			else if(max<10000)
				max=max*2;
			else
				max=max+1000;
		}else{
			max=contents.length+newItems-1;
			pointer=contents.length;
		}

        temp_s=contents;
        contents = new String[max];
        System.arraycopy( temp_s, 0, contents, 0, pointer );

        temp_s=rawData;
        rawData = new String[max];
        System.arraycopy( temp_s, 0, rawData, 0, pointer );

		temp_s=unformattedContent;
        unformattedContent = new String[max];
        System.arraycopy( temp_s, 0, unformattedContent, 0, pointer );

        temp_i=f_writingMode;
        f_writingMode=new int[max];
        f_writingMode = new int[max];
        System.arraycopy( temp_i, 0, f_writingMode, 0, pointer );

        temp_s=f_font_used;
        f_font_used = new String[max];
        System.arraycopy( temp_s, 0, f_font_used, 0, pointer );

        temp_s=colorTag;
        colorTag = new String[max];
        System.arraycopy( temp_s, 0, colorTag, 0, pointer );

        temp_s=font_data;
        font_data = new String[max];
        System.arraycopy( temp_s, 0, font_data, 0, pointer );

        temp_s=fragments;
        fragments = new String[max];
        System.arraycopy( temp_s, 0, fragments, 0, pointer );

        temp_i=text_length;
        text_length = new int[max];
        System.arraycopy( temp_i, 0, text_length, 0, pointer );

        temp_i=lineCount;
        lineCount = new int[max];
        System.arraycopy( temp_i, 0, lineCount, 0, pointer );

        temp_i=move_command;
        move_command = new int[max];
        System.arraycopy( temp_i, 0, move_command, 0, pointer );

        temp_f=f_character_spacing;
        f_character_spacing = new float[max];
        System.arraycopy( temp_f, 0, f_character_spacing, 0, pointer );

        temp_i=parent;
        parent = new int[max];
        //set to default -1
        for(int ii=pointer;ii<max;ii++)
            parent[ii]=-1;
        System.arraycopy( temp_i, 0, parent, 0, pointer );

        temp_s=prefix;
        prefix = new String[max];
        //set to default -1
        for(int ii=pointer;ii<max;ii++)
            prefix[ii]=null;
        System.arraycopy( temp_s, 0, prefix, 0, pointer );

        temp_i=token_counter;
        token_counter = new int[max];
        System.arraycopy( temp_i, 0, token_counter, 0, pointer );

        Object[] temp_o=links;
        links = new Object[max];
        System.arraycopy( temp_o, 0, links, 0, pointer );

        temp_s=category;
        category = new String[max];
        System.arraycopy( temp_s, 0, category, 0, pointer );

        temp_i=objectType;
        objectType = new int[max];
        System.arraycopy( temp_i, 0, objectType, 0, pointer );


        temp_i=f_end_font_size;
        f_end_font_size = new int[max];
        System.arraycopy( temp_i, 0, f_end_font_size, 0, pointer );

        temp_f=space_width;
        space_width = new float[max];
        System.arraycopy( temp_f, 0, space_width, 0, pointer );

        temp_f=f_x1;
        f_x1 = new float[max];
        System.arraycopy( temp_f, 0, f_x1, 0, pointer );

        temp_f=f_x2;
        f_x2 = new float[max];
        System.arraycopy( temp_f, 0, f_x2, 0, pointer );

        temp_f=f_y1;
        f_y1 = new float[max];
        System.arraycopy( temp_f, 0, f_y1, 0, pointer );

        temp_f=f_y2;
        f_y2 = new float[max];
        System.arraycopy( temp_f, 0, f_y2, 0, pointer );
    }

    /**
     * remove a Text Object
     */
    final public void removeTextElementAt( int counter )
    {
        text_objects.remove( new Integer(counter) );

    }

    /**
     * return id of raw fragments stored as space deliminated string
     */
    public String getFragments(int i) {

        return fragments[i];
    }

    /**
     * get parent item for linked items
     */
    public int getParent(int item_selected) {
        return parent[item_selected];
    }

    /**
     * set prefix item for linked items
     */
    public String getPrefix(int item_selected) {
        return prefix[item_selected];
    }

    /**
     * set prefix
     */
    public void setPrefix(int item, String prefixValue){

        //resize if needed
        int size=prefix.length;
        if(item>=size){
            max=prefix.length+100;
            String[] temp_i=prefix;
            prefix = new String[max];
            System.arraycopy( temp_i, 0, prefix, 0, size );

            //fill up gaps with -1
            for(int j=size;j<max;j++)
                prefix[j]=null;
        }

        prefix[item]=prefixValue;
    }

    /**
     * set parent
     */
    public void setParent(int item, int parentID){
        //System.out.println("set parent="+item+" "+parentID);
        //resize if needed
        int size=parent.length;
        if(item>=size){
            max=parent.length+100;
            int[] temp_i=parent;
            parent = new int[max];
            System.arraycopy( temp_i, 0, parent, 0, size );

            //fill up gaps with -1
            for(int j=size;j<max;j++)
                parent[j]=-1;
        }

        parent[item]=parentID;
    }

    /**
     * set flag to show width in text
     */
    public void widthIsEmbedded() {

        widthIsEmbedded=true;

    }

    /**
     * show if width in text
     */
    public boolean IsEmbedded() {

        return widthIsEmbedded;

    }
    
    /**fonts size of object - if it changes in object will be FIRST value*/
    public int getFontSize(int currentStory) {
        return fontSize[currentStory];
    }

    /**tag font at start of object*/
    public String getFontTag(int currentStory) {
        return f_font_used[currentStory];
    }

    public String getGlobalField(String globalField) {


        return (String) globalValues.get(globalField);
    }

    public void setGlobalField(String globalNameForCategory,String value) {
        globalValues.put(globalNameForCategory,value);
    }

	public void setMetaFieldUserDefinable(String globalNameForCategory) {
        globalSettings.put("editable-"+globalNameForCategory,"x");
    }

	public boolean isMetaFieldUserDefinable(String globalNameForCategory) {
        return globalSettings.get("editable-"+globalNameForCategory)!=null;
    }

	public void setMetaFieldValues(String globalNameForCategory,String value) {
        globalSettings.put("values-"+globalNameForCategory,value);
    }

	public String getMetaFieldValues(String globalNameForCategory) {
        return (String) globalSettings.get("values-"+globalNameForCategory);
    }


	public Object[] getGlobalFields() {
        return globalValues.keySet().toArray();
    }

    public int getGlobalCategoryCount() {
        return globalValues.size();
    }

    /**
     * flag set when regexp applied
     */
    public int getRegExpStatus(int i) {

        return regExpStatus[i];
    }

    /**
     * set regexp status
     */
    public void setRegExpStatus(int item, int value){

        //resize if needed
        int size=regExpStatus.length;
        if(item>=size){
            max=regExpStatus.length+100;
            if(item>max)
            	max=item+20;
            int[] temp_i=regExpStatus;
            regExpStatus = new int[max];
            System.arraycopy( temp_i, 0, regExpStatus, 0, size );

            //fill up gaps with -1
            for(int j=size;j<max;j++)
                regExpStatus[j]=-1;
        }

        regExpStatus[item]=value;
    }



	public void addExtractedXMLField(String fieldName, String data,int id) {
		
		Integer key=new Integer(id);
		
		//get existing value and create if needed
		Map currentExtractedFields=(Map) extractedXMLFields.get(key);
		if(currentExtractedFields==null)
			currentExtractedFields=new HashMap();
		
		//add to existing value and store
		String currentValue=(String) currentExtractedFields.get(fieldName);
		if(currentValue!=null)
			data=currentValue+data;
		//System.out.println("add "+fieldName);
		currentExtractedFields.put(fieldName,data);
		
		//save at end
		extractedXMLFields.put(key,currentExtractedFields);
		
	}

	public Map getExtractedTextFields(int id) {
		
		return (Map) extractedTextFields.get(new Integer(id));
	}
	
	public Map getExtractedXMLFields(int id) {
		
		return (Map) extractedXMLFields.get(new Integer(id));
	}
	
	public void resetExtractedTextFields(int id,Map values) {
		
		extractedTextFields.put(new Integer(id),values);
	}

	public void flushExtractedFields() {
		extractedTextFields.clear();
		extractedXMLFields.clear();
		
	}

    /**used to pass in actual data*/
    public void setMarkedContent(StringBuffer markedContent) {
        this.markedContent=markedContent;
        isMarked=true;
    }


    /**used by Storypad to show how many pages stored*/
    public int getPageCount() {
        return 1+this.additionalPageCount; 
    }
}
