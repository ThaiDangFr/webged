/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 * Project Lead:  Mark Stephens (mark@idrsolutions.com)
 *
 * (C) Copyright 2005, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 *
 * ---------------
 * ActionHandler.java
 * ---------------
 * (C) Copyright 2006, by IDRsolutions and Contributors.
 *
 * 
 * --------------------------
 */
package org.jpedal.objects.acroforms;

import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeListener;
import java.util.Map;

public interface ActionHandler {
	
	/**
	 * creates and returns a mouseListener to perform the required command
	 */
	public MouseListener setupCommand(String string,AcroRenderer acrorend);

	/**
	 * creates and returns mouse listener to perform required actions
	 */
	public MouseListener setupEnteredAction(Map enteredAction, AcroRenderer acrorenderer);

	/**
	 * creates and returns a mouse listener that will perform the required actions
	 */
	public MouseListener setupExitedAction(Map exitedAction, AcroRenderer acrorenderer);

	/**
	 * creates and returns a mouse listener that will perform the required actions
	 */
	public MouseListener setupHideAction(Map hideMap, AcroRenderer acrorenderer);

	/**
	 * creates and returns a mouse listener that will perform the required actions
	 */
	public MouseListener setupClickedAction(Map activateAction, AcroRenderer acrorenderer);

	/**
	 * creates a returns an action listener that will change the down icon for each click
	 */
	public ActionListener setupChangingDownIcon(BufferedImage downOff, BufferedImage downOn);

	/**
	 * setup action to read required forms data and perform submit action
	 */
	public MouseListener setupSubmitAction(Map dataMap,AcroRenderer acrorend);

	/**
	 * setup mouse actions to allow the text of the button to change with the captions provided
	 */
	public MouseListener setupChangingCaption(String normalCaption,String rolloverCaption,String downCaption);

	/**
	 * set the combobox to show its options on entry to field
	 */
	public MouseListener setComboClickOnEntry();


	/**
	 * setup value change validate option
	 */
	public PropertyChangeListener setupValidateAction(String validateValue);
}
