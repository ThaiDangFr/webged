package org.jpedal.parser;

public interface StreamDecoder {

}
